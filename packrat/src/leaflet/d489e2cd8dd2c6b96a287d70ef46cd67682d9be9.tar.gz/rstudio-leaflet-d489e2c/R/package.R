#' @importFrom magrittr %>%
#' @export %>%
#' @importFrom htmlwidgets JS
#' @importFrom grDevices col2rgb rgb
#' @importFrom methods substituteDirect
#' @importFrom stats na.omit quantile
#' @importFrom utils getFromNamespace packageVersion
#' @export JS
NULL
