We can add a download button to the UI using `downloadButton()`, and write
the content of the file in `downloadHandler()` in the `server` function.
